<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"snapchat");
$fullname=trim($_POST['Full_name']);
$username=trim($_POST['Username']);
$email=trim($_POST['Email']);
$phoneno=trim($_POST['Phone_No']);
$password=trim($_POST['Password']);

$qry1="SELECT * FROM `snapchat` WHERE email='$email'";
$raw=mysqli_query($conn,$qry1);
$count=mysqli_num_rows($raw);

if($count>0)
{
    $response="Already Exists";
}
else{
      $qry2="INSERT INTO 'snapchat' (`Full_name`, `Username`, `Email`, `Phone_No`, `Password`)
       VALUES ('$fullname', '$username', '$email', '$phoneno', '$password');";
       $res=mysqli_query($conn,$qry2);
       if($res==true)
       $response="Succesfully SignUp";
       else
       $response="Failed to SignUp";
}
echo $response;

?>