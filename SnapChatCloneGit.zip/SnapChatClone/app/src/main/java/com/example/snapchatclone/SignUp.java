package com.example.snapchatclone;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("ALL")
public class SignUp<TIMEOUT_MS> extends AppCompatActivity {

    EditText sname, susername, semail, sphone, spass;
    Button buttn;

    private static final String url="http://192.168.1.34/shruu/snapchat.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_sign_up );

        sname= findViewById ( R.id.name);
        susername= findViewById ( R.id.username);
        semail= findViewById ( R.id.email);
        sphone= findViewById ( R.id.phone);
        spass= findViewById ( R.id.pass);
        buttn= findViewById ( R.id.signup_btn);

        buttn.setOnClickListener ( view -> register_user( sname.getText().toString(), susername.getText().toString(),
                                                  semail.getText().toString(), sphone.getText().toString(),
                                                  spass.getText().toString ()) );
    }

    private void register_user(final String name,final String username, final String email,
                               final String phone, final String pass)
    {
        StringRequest request = new StringRequest ( Request.Method.POST, url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                sname.equals("");
                susername.equals("");
                semail.equals("");
                sphone.equals("");
                spass.equals("");
                Toast.makeText( getApplicationContext(), response, Toast.LENGTH_LONG).show();
            }
       }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                sname.equals ( "" );
                susername.equals ( "" );
                semail.equals ( "" );
                sphone.equals ( "" );
                spass.equals ( "" );

                Toast.makeText ( getApplicationContext (), error.toString (), Toast.LENGTH_LONG ).show ();
            }
        }
        ){
            @NonNull
            @Override
            protected Map<String, String> getParams()  throws AuthFailureError {
                Map <String, String> map= new HashMap<String, String> ();
                map.put("Full_Name",name);
                map.put("Username",username);
                map.put("Email",email);
                map.put("Phone_No",phone);
                map.put("Password",pass);
                return map;
            }
        };
            RequestQueue queue = Volley.newRequestQueue ( getApplicationContext ());
            queue.add(request);
    }
}
