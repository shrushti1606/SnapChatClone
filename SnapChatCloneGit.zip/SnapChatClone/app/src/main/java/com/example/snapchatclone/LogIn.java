package com.example.snapchatclone;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class LogIn extends AppCompatActivity {

    EditText sname,spass;
    Button log_in,btn;
    private static final String url1 ="http:///192.168.1.34/shruu/SnapLogin.php";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        sname = findViewById(R.id.username);
        spass = findViewById(R.id.password);
        btn = findViewById(R.id.btn2);

        btn.setOnClickListener( view -> login_user( sname.getText().toString(), spass.getText().toString()) );

        log_in = findViewById(R.id.login_btn);
        log_in.setOnClickListener(view -> {
            Intent intent = new Intent( LogIn.this, Dashboard.class);
            startActivity(intent);
        });
    }
    //This function is used to login
    public void login_user(final String sname, final String spass)
    {
        StringRequest request = new StringRequest( Request.Method.POST, url1, response -> {
            sname.equals("");
            spass.equals("");

            Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();

        }, error -> {
            sname.equals("");
            spass.equals("");

            Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_LONG).show();

        }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() {
                Map<String,String> map = new HashMap<> ();

                map.put("username",sname);
                map.put("password",spass);
                return map;
            }
        };
        RequestQueue queue= Volley.newRequestQueue(getApplicationContext());
        queue.add(request);
    }
}