package com.example.snapchatclone;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Intro extends AppCompatActivity {

    EditText username, password;
    Button btn1, btn2;

    @SuppressLint({ "WrongViewCast", "MissingInflatedId" })
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView ( R.layout.activity_intro );

        username= findViewById ( R.id.textView2);
        password= findViewById ( R.id.textView5);
        btn1= findViewById ( R.id.login_btn);

        btn1 = findViewById ( R.id.button2 );
        btn1.setOnClickListener (view ->{
            Intent intent = new Intent (Intro.this, LogIn.class);
            startActivity (intent);
        });

        btn2 = findViewById ( R.id.button );
        btn2.setOnClickListener (view ->{
            Intent intent = new Intent (Intro.this, SignUp.class);
            startActivity (intent);
        });
    }
}