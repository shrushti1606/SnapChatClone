<?php

$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"snaplogin");
$username=$_POST['USERNAME'];
$password=$_POST['PASSWORD'];

$qry="select * from `login` WHERE  USERNAME='$username' and PASSWORD='$password'";
$raw=mysqli_query($conn,$qry);
$count=mysqli_num_rows($raw);

if ($count>0) {
    echo"Login Successfully"
}else {
    echo"Login Failed"
}